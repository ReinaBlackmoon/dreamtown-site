DreamTown — Windows install

1. Extract this ZIP (Extract All).
2. Double-click DreamTown-Setup.bat
3. Play from Desktop shortcut "DreamTown"

Requires landscape display. Uninstall: delete folder %LOCALAPPDATA%\DreamTown
