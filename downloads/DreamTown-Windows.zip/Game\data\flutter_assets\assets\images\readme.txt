Drop AI-generated PNGs here (optional — game uses painted sprites if missing):
  mayor.png      — pink girl mayor
  bunny_npc.png  — Baker Bunny
  pet_cloud.png  — Cloud Bunny
