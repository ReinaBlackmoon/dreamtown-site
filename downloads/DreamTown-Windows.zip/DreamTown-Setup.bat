@echo off
title DreamTown Setup
cd /d "%~dp0"
set "GAME_DIR=%~dp0Game"
set "INSTALL=%LOCALAPPDATA%\DreamTown"

if not exist "%GAME_DIR%\dreamtown.exe" (
  echo ERROR: Game files missing. Extract the full ZIP first.
  pause
  exit /b 1
)

echo.
echo Installing DreamTown to:
echo   %INSTALL%
echo.

if not exist "%INSTALL%" mkdir "%INSTALL%"
xcopy /E /Y /I /Q "%GAME_DIR%\*" "%INSTALL%\" >nul
if errorlevel 1 (
  echo Copy failed.
  pause
  exit /b 1
)

set "SHORTCUT=%USERPROFILE%\Desktop\DreamTown.lnk"
powershell -NoProfile -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath='%INSTALL%\dreamtown.exe'; $s.WorkingDirectory='%INSTALL%'; $s.Description='DreamTown'; $s.Save()" 2>nul

echo.
echo Done! Starting DreamTown...
echo Desktop shortcut: DreamTown
echo.
start "" "%INSTALL%\dreamtown.exe"
timeout /t 3 /nobreak >nul
exit /b 0
