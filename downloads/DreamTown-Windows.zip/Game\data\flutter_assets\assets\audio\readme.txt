Optional audio files: village_loop.mp3, coin.mp3, quest.mp3, click.mp3, levelup.mp3, chest.mp3
The game uses system sounds when these are missing.
